<?xml version="1.0" ?><!DOCTYPE TS><TS language="la" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About FuelCoin</source>
        <translation>Informatio de FuelCoin</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;FuelCoin&lt;/b&gt; version</source>
        <translation>&lt;b&gt;FuelCoin&lt;/b&gt; versio</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>Hoc est experimentale programma.

Distributum sub MIT/X11 licentia programmatum, vide comitantem plicam COPYING vel http://www.opensource.org/licenses/mit-license.php.

Hoc productum continet programmata composita ab OpenSSL Project pro utendo in OpenSSL Toolkit (http://www.openssl.org/) et programmata cifrarum scripta ab Eric Young (eay@cryptsoft.com) et UPnP programmata scripta ab Thomas Bernard.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="+14"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The FuelCoin developers</source>
        <translation>FuelCoin curatores</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>Address Book</source>
        <translation>Liber Inscriptionum</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Double-click to edit address or label</source>
        <translation>Dupliciter-clicca ut inscriptionem vel titulum mutes</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Create a new address</source>
        <translation>Crea novam inscriptionem</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia inscriptionem iam selectam in latibulum systematis</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>&amp;New Address</source>
        <translation>&amp;Nova Inscriptio</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+63"/>
        <source>These are your FuelCoin addresses for receiving payments. You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Haec sunt inscriptiones FuelCoin tuae pro accipendo pensitationes.  Cupias variam ad quemque mittentem dare ut melius scias quem tibi pensare.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copia Inscriptionem</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Show &amp;QR Code</source>
        <translation>Monstra codicem &amp;QR</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Sign a message to prove you own a FuelCoin address</source>
        <translation>Signa nuntium ut demonstres inscriptionem FuelCoin a te possessam esse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Signa &amp;Nuntium</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Delete the currently selected address from the list</source>
        <translation>Dele active selectam inscriptionem ex enumeratione</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta data in hac tabella in plicam</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Export</source>
        <translation>&amp;Exporta</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Verify a message to ensure it was signed with a specified FuelCoin address</source>
        <translation>Verifica nuntium ut cures signatum esse cum specificata inscriptione FuelCoin</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica Nuntium</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Delete</source>
        <translation>&amp;Dele</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="-5"/>
        <source>These are your FuelCoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Hae sunt inscriptiones mittendi pensitationes.  Semper inspice quantitatem et inscriptionem accipiendi antequam nummos mittis.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Copy &amp;Label</source>
        <translation>Copia &amp;Titulum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Edit</source>
        <translation>&amp;Muta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send &amp;Coins</source>
        <translation>Mitte &amp;Nummos</translation>
    </message>
    <message>
        <location line="+260"/>
        <source>Export Address Book Data</source>
        <translation>Exporta Data Libri Inscriptionum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma Separata Plica (*.csv)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Error exporting</source>
        <translation>Error exportandi</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Non potuisse scribere in plicam %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+144"/>
        <source>Label</source>
        <translation>Titulus</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Inscriptio</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(nullus titulus)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>Dialogus Tesserae</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>Insere tesseram</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>Nova tessera</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>Itera novam tesseram</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+33"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Insero novam tesseram cassidili.&lt;br/&gt;Sodes tessera &lt;b&gt;10 pluriumve fortuitarum litterarum&lt;/b&gt; utere aut &lt;b&gt;octo pluriumve verborum&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>Cifra cassidile</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Huic operationi necesse est tessera cassidili tuo ut cassidile reseret.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>Resera cassidile</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Huic operationi necesse est tessera cassidili tuo ut cassidile decifret.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>Decifra cassidile</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>Muta tesseram</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Insero veterem novamque tesseram cassidili.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>Confirma cifrationem cassidilis</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>Monitio: Si cassidile tuum cifras et tesseram amittis, tu &lt;b&gt;AMITTES OMNES TUOS NUMMOS BITOS&lt;/b&gt;!</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Certusne es te velle tuum cassidile cifrare?</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>GRAVE: Oportet ulla prioria conservata quae fecisti de plica tui cassidilis reponi a nove generata cifrata plica cassidilis.  Propter securitatem, prioria conservata de plica non cifrata cassidilis inutilia fiet simul atque incipis uti novo cifrato cassidili.</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Monitio: Litterae ut capitales seratae sunt!</translation>
    </message>
    <message>
        <location line="-130"/>
        <location line="+58"/>
        <source>Wallet encrypted</source>
        <translation>Cassidile cifratum</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>FuelCoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your FuelCoins from being stolen by malware infecting your computer.</source>
        <translation>FuelCoin iam desinet ut finiat actionem cifrandi.  Memento cassidile cifrare non posse cuncte curare ne tui nummi clepantur ab malis programatibus in tuo computatro.</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+7"/>
        <location line="+42"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>Cassidile cifrare abortum est</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Cassidile cifrare abortum est propter internum errorem.  Tuum cassidile cifratum non est.</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+48"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Tesserae datae non eaedem sunt.</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Wallet unlock failed</source>
        <translation>Cassidile reserare abortum est.</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+11"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Tessera inserta pro cassidilis decifrando prava erat.</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>Cassidile decifrare abortum est.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Tessera cassidilis successa est in mutando.</translation>
    </message>
</context>
<context>
    <name>FuelCoinGUI</name>
    <message>
        <location filename="../FuelCoingui.cpp" line="+233"/>
        <source>Sign &amp;message...</source>
        <translation>Signa &amp;nuntium...</translation>
    </message>
    <message>
        <location line="+280"/>
        <source>Synchronizing with network...</source>
        <translation>Synchronizans cum rete...</translation>
    </message>
    <message>
        <location line="-349"/>
        <source>&amp;Overview</source>
        <translation>&amp;Summarium</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show general overview of wallet</source>
        <translation>Monstra generale summarium cassidilis</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transactiones</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>Inspicio historiam transactionum</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Muta indicem salvatarum inscriptionum titulorumque</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Monstra indicem inscriptionum quibus pensitationes acceptandae</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>E&amp;xit</source>
        <translation>E&amp;xi</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>Exi applicatione</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Show information about FuelCoin</source>
        <translation>Monstra informationem de FuelCoin</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>About &amp;Qt</source>
        <translation>Informatio de &amp;Qt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show information about Qt</source>
        <translation>Monstra informationem de Qt</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Options...</source>
        <translation>&amp;Optiones</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Cifra Cassidile...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Conserva Cassidile...</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Muta tesseram...</translation>
    </message>
    <message>
        <location line="+285"/>
        <source>Importing blocks from disk...</source>
        <translation>Importans frusta ab disco...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Reindexing blocks on disk...</source>
        <translation>Recreans indicem frustorum in disco...</translation>
    </message>
    <message>
        <location line="-347"/>
        <source>Send coins to a FuelCoin address</source>
        <translation>Mitte nummos ad inscriptionem FuelCoin</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Modify configuration options for FuelCoin</source>
        <translation>Muta configurationis optiones pro FuelCoin</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Backup wallet to another location</source>
        <translation>Conserva cassidile in locum alium</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Muta tesseram utam pro cassidilis cifrando</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Debug window</source>
        <translation>Fenestra &amp;Debug</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>Aperi terminalem debug et diagnosticalem</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifica nuntium...</translation>
    </message>
    <message>
        <location line="-165"/>
        <location line="+530"/>
        <source>FuelCoin</source>
        <translation>FuelCoin</translation>
    </message>
    <message>
        <location line="-530"/>
        <source>Wallet</source>
        <translation>Cassidile</translation>
    </message>
    <message>
        <location line="+101"/>
        <source>&amp;Send</source>
        <translation>&amp;Mitte</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Receive</source>
        <translation>&amp;Accipe</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Addresses</source>
        <translation>&amp;Inscriptiones</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>&amp;About FuelCoin</source>
        <translation>&amp;Informatio de FuelCoin</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Monstra/Occulta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show or hide the main Window</source>
        <translation>Monstra vel occulta Fenestram principem</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Cifra claves privatas quae cassidili tui sunt</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Sign messages with your FuelCoin addresses to prove you own them</source>
        <translation>Signa nuntios cum tuis inscriptionibus FuelCoin ut demonstres te eas possidere</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Verify messages to ensure they were signed with specified FuelCoin addresses</source>
        <translation>Verifica nuntios ut certus sis eos signatos esse cum specificatis inscriptionibus FuelCoin</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>&amp;File</source>
        <translation>&amp;Plica</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Settings</source>
        <translation>&amp;Configuratio</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Help</source>
        <translation>&amp;Auxilium</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Tabs toolbar</source>
        <translation>Tabella instrumentorum &quot;Tabs&quot;</translation>
    </message>
    <message>
        <location line="+17"/>
        <location line="+10"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location line="+47"/>
        <source>FuelCoin client</source>
        <translation>FuelCoin cliens</translation>
    </message>
    <message numerus="yes">
        <location line="+141"/>
        <source>%n active connection(s) to FuelCoin network</source>
        <translation><numerusform>%n activa conexio ad rete FuelCoin</numerusform><numerusform>%n activae conexiones ad rete FuelCoin</numerusform></translation>
    </message>
    <message>
        <location line="+22"/>
        <source>No block source available...</source>
        <translation>Nulla fons frustorum absens...</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>Perfecta %1 de %2 (aestimato) frusta historiae transactionum.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>Processae %1 frusta historiae transactionum.</translation>
    </message>
    <message numerus="yes">
        <location line="+20"/>
        <source>%n hour(s)</source>
        <translation><numerusform>%n hora</numerusform><numerusform>%n horae</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n dies</numerusform><numerusform>%n dies</numerusform></translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n week(s)</source>
        <translation><numerusform>%n hebdomas</numerusform><numerusform>%n hebdomades</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1 behind</source>
        <translation>%1 post</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Last received block was generated %1 ago.</source>
        <translation>Postremum acceptum frustum generatum est %1 abhinc.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transactiones post hoc nondum visibiles erunt.</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning</source>
        <translation>Monitio</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Information</source>
        <translation>Informatio</translation>
    </message>
    <message>
        <location line="+70"/>
        <source>This transaction is over the size limit. You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network. Do you want to pay the fee?</source>
        <translation>Haec transactio maior est quam limen magnitudinis.  Adhuc potes id mittere mercede %1, quae it nodis qui procedunt tuam transactionem et adiuvat sustinere rete.  Visne mercedem solvere?</translation>
    </message>
    <message>
        <location line="-140"/>
        <source>Up to date</source>
        <translation>Recentissimo</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Catching up...</source>
        <translation>Persequens...</translation>
    </message>
    <message>
        <location line="+113"/>
        <source>Confirm transaction fee</source>
        <translation>Confirma mercedem transactionis</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Sent transaction</source>
        <translation>Transactio missa</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Incoming transaction</source>
        <translation>Transactio incipiens</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Dies: %1
Quantitas: %2
Typus: %3
Inscriptio: %4
</translation>
    </message>
    <message>
        <location line="+33"/>
        <location line="+23"/>
        <source>URI handling</source>
        <translation>Tractatio URI</translation>
    </message>
    <message>
        <location line="-23"/>
        <location line="+23"/>
        <source>URI can not be parsed! This can be caused by an invalid FuelCoin address or malformed URI parameters.</source>
        <translation>URI intellegi non posse!  Huius causa possit inscriptionem FuelCoin non validam aut URI parametra maleformata.</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Cassidile &lt;b&gt;cifratum&lt;/b&gt; est et iam nunc &lt;b&gt;reseratum&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Cassidile &lt;b&gt;cifratum&lt;/b&gt; est et iam nunc &lt;b&gt;seratum&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../FuelCoin.cpp" line="+111"/>
        <source>A fatal error occurred. FuelCoin can no longer continue safely and will quit.</source>
        <translation>Error fatalis accidit.  FuelCoin nondum pergere tute potest, et exibit.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+104"/>
        <source>Network Alert</source>
        <translation>Monitio Retis</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>Muta Inscriptionem</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>&amp;Titulus</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The label associated with this address book entry</source>
        <translation>Titulus associatus huic insertione libri inscriptionum</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Address</source>
        <translation>&amp;Inscriptio</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Titulus associatus huic insertione libri inscriptionum.  Haec tantum mutari potest pro inscriptionibus mittendi</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+21"/>
        <source>New receiving address</source>
        <translation>Nova inscriptio accipiendi</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>Nova inscriptio mittendi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>Muta inscriptionem accipiendi</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>Muta inscriptionem mittendi</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Inserta inscriptio &quot;%1&quot; iam in libro inscriptionum est.</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>The entered address &quot;%1&quot; is not a valid FuelCoin address.</source>
        <translation>Inscriptio inserta &quot;%1&quot; non valida inscriptio FuelCoin est.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Could not unlock wallet.</source>
        <translation>Non potuisse cassidile reserare</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>Generare novam clavem abortum est.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    <message>
        <location filename="../guiutil.cpp" line="+424"/>
        <location line="+12"/>
        <source>FuelCoin-Qt</source>
        <translation>FuelCoin-Qt</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>version</source>
        <translation>versio</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>Usus:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>Optiones mandati intiantis</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>UI optiones</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Constitue linguam, exempli gratia &quot;de_DE&quot; (praedefinitum: lingua systematis)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>Incipe minifactum ut icon</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Monstra principem imaginem ad initium (praedefinitum: 1)</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>Optiones</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Main</source>
        <translation>&amp;Princeps</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation>Optionalis merces transactionum singulis kB quae adiuvat curare tuas transactiones processas esse celeriter.  Plurimi transactiones 1kB sunt.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Solve &amp;mercedem transactionis</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start FuelCoin after logging in to the system.</source>
        <translation>Pelle FuelCoin per se postquam in systema inire.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start FuelCoin on system login</source>
        <translation>&amp;Pelle FuelCoin cum inire systema</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Reset all client options to default.</source>
        <translation>Reconstitue omnes optiones clientis ad praedefinita.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Reset Options</source>
        <translation>&amp;Reconstitue Optiones</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Network</source>
        <translation>&amp;Rete</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Automatically open the FuelCoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Aperi per se portam clientis FuelCoin in itineratore.  Hoc tantum effectivum est si itineratrum tuum supportat UPnP et id activum est.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Designa portam utendo &amp;UPnP</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Connect to the FuelCoin network through a SOCKS proxy (e.g. when connecting through Tor).</source>
        <translation>Connecte ad rete FuelCoin per SOCKS vicarium (e.g. quando conectens per Tor).</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy:</source>
        <translation>&amp;Conecte per SOCKS vicarium:</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP vicarii:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>Inscriptio IP vicarii (e.g. 127.0.0.1)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Port:</source>
        <translation>&amp;Porta:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Porta vicarii (e.g. 9050)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS &amp;Versio:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>SOCKS versio vicarii (e.g. 5)</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Window</source>
        <translation>&amp;Fenestra</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Monstra tantum iconem in tabella systematis postquam fenestram minifactam est.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minifac in tabellam systematis potius quam applicationum</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minifac potius quam exire applicatione quando fenestra clausa sit.  Si haec optio activa est, applicatio clausa erit tantum postquam selegeris Exi in menu.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inifac ad claudendum</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>&amp;UI</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Lingua monstranda utenti:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The user interface language can be set here. This setting will take effect after restarting FuelCoin.</source>
        <translation>Lingua monstranda utenti hic constitui potest.  Haec configuratio effectiva erit postquam FuelCoin iterum initiatum erit.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unita qua quantitates monstrare:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Selige praedefinitam unitam subdivisionis monstrare in interfacie et quando nummos mittere</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Whether to show FuelCoin addresses in the transaction list or not.</source>
        <translation>Num monstrare inscriptiones FuelCoin in enumeratione transactionum.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>&amp;Monstra inscriptiones in enumeratione transactionum</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Apply</source>
        <translation>&amp;Applica</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+53"/>
        <source>default</source>
        <translation>praedefinitum</translation>
    </message>
    <message>
        <location line="+130"/>
        <source>Confirm options reset</source>
        <translation>Confirma optionum reconstituere</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Some settings may require a client restart to take effect.</source>
        <translation>Aliis configurationibus fortasse necesse est clientem iterum initiare ut effectivae sint.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Do you want to proceed?</source>
        <translation>Vis procedere?</translation>
    </message>
    <message>
        <location line="+42"/>
        <location line="+9"/>
        <source>Warning</source>
        <translation>Monitio</translation>
    </message>
    <message>
        <location line="-9"/>
        <location line="+9"/>
        <source>This setting will take effect after restarting FuelCoin.</source>
        <translation>Haec configuratio effectiva erit postquam FuelCoin iterum initiatum erit.</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>Inscriptio vicarii tradita non valida est.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+14"/>
        <source>Form</source>
        <translation>Schema</translation>
    </message>
    <message>
        <location line="+50"/>
        <location line="+166"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the FuelCoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Monstrata informatio fortasse non recentissima est.  Tuum cassidile per se synchronizat cum rete FuelCoin postquam conexio constabilita est, sed hoc actio nondum perfecta est.</translation>
    </message>
    <message>
        <location line="-124"/>
        <source>Balance:</source>
        <translation>Pendendum:</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Unconfirmed:</source>
        <translation>Non confirmata:</translation>
    </message>
    <message>
        <location line="-78"/>
        <source>Wallet</source>
        <translation>Cassidile</translation>
    </message>
    <message>
        <location line="+107"/>
        <source>Immature:</source>
        <translation>Immatura:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Mined balance that has not yet matured</source>
        <translation>Fossum pendendum quod nondum maturum est</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Recentes transactiones&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="-101"/>
        <source>Your current balance</source>
        <translation>Tuum pendendum iam nunc</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Totali nummi transactionum quae adhuc confirmandae sunt, et nondum afficiunt pendendum</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+116"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>non synchronizato</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <location filename="../paymentserver.cpp" line="+107"/>
        <source>Cannot start FuelCoin: click-to-pay handler</source>
        <translation>FuelCoin incipere non potest: cliccare-ad-pensandum handler</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="+14"/>
        <source>QR Code Dialog</source>
        <translation>Dialogus QR Codicis</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Request Payment</source>
        <translation>Posce Pensitationem</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Amount:</source>
        <translation>Quantitas:</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Label:</source>
        <translation>Titulus:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Message:</source>
        <translation>Nuntius:</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Salva ut...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="+62"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Error codificandi URI in codicem QR.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>The entered amount is invalid, please check.</source>
        <translation>Inserta quantitas non est valida, sodes proba.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resultato URI nimis longo, conare minuere verba pro titulo / nuntio.</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Save QR Code</source>
        <translation>Salva codicem QR</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Images (*.png)</source>
        <translation>Imagines PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+46"/>
        <source>Client name</source>
        <translation>Nomen clientis</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+53"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+339"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location line="-217"/>
        <source>Client version</source>
        <translation>Versio clientis</translation>
    </message>
    <message>
        <location line="-45"/>
        <source>&amp;Information</source>
        <translation>&amp;Informatio</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Using OpenSSL version</source>
        <translation>Utens OpenSSL versione</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Startup time</source>
        <translation>Tempus initiandi</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Network</source>
        <translation>Rete</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Number of connections</source>
        <translation>Numerus conexionum</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>On testnet</source>
        <translation>In testnet</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Block chain</source>
        <translation>Catena frustorum</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Current number of blocks</source>
        <translation>Numerus frustorum iam nunc</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Estimated total blocks</source>
        <translation>Aestimatus totalis numerus frustorum</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last block time</source>
        <translation>Hora postremi frusti</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>&amp;Open</source>
        <translation>&amp;Aperi</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Command-line options</source>
        <translation>Optiones mandati initiantis</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Show the FuelCoin-Qt help message to get a list with possible FuelCoin command-line options.</source>
        <translation>Monstra nuntium auxilii FuelCoin-Qt ut videas enumerationem possibilium optionum FuelCoin mandati initiantis.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Show</source>
        <translation>&amp;Monstra</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Console</source>
        <translation>&amp;Terminale</translation>
    </message>
    <message>
        <location line="-260"/>
        <source>Build date</source>
        <translation>Dies aedificandi</translation>
    </message>
    <message>
        <location line="-104"/>
        <source>FuelCoin - Debug window</source>
        <translation>FuelCoin - Fenestra debug</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>FuelCoin Core</source>
        <translation>FuelCoin Nucleus</translation>
    </message>
    <message>
        <location line="+279"/>
        <source>Debug log file</source>
        <translation>Debug catalogi plica</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Open the FuelCoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Aperi plicam catalogi de FuelCoin debug ex activo indice datorum.  Hoc possit pauca secunda pro plicis magnis catalogi.</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>Clear console</source>
        <translation>Vacuefac terminale</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-30"/>
        <source>Welcome to the FuelCoin RPC console.</source>
        <translation>Bene ventio in terminale RPC de FuelCoin.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Utere sagittis sursum deorsumque ut per historiam naviges, et &lt;b&gt;Ctrl+L&lt;/b&gt; ut scrinium vacuefacias.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Scribe &lt;b&gt;help&lt;/b&gt; pro summario possibilium mandatorum.</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+124"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+6"/>
        <location line="+5"/>
        <location line="+5"/>
        <source>Send Coins</source>
        <translation>Mitte Nummos</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Send to multiple recipients at once</source>
        <translation>Mitte pluribus accipientibus simul</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>Adde &amp;Accipientem</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Remove all transaction fields</source>
        <translation>Remove omnes campos transactionis</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear &amp;All</source>
        <translation>Vacuefac &amp;Omnia</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Balance:</source>
        <translation>Pendendum:</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>123.456 FUEL</source>
        <translation>123.456 FUEL</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Confirm the send action</source>
        <translation>Confirma actionem mittendi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>&amp;Mitte</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-59"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; ad %2 (%3)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm send coins</source>
        <translation>Confirma mittendum nummorum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Certus es te velle mittere %1?</translation>
    </message>
    <message>
        <location line="+0"/>
        <source> and </source>
        <translation>et</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Inscriptio accipientis non est valida, sodes reproba.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Oportet quantitatem ad pensandum maiorem quam 0 esse.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount exceeds your balance.</source>
        <translation>Quantitas est ultra quod habes.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Quantitas est ultra quod habes cum merces transactionis %1 includitur.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Geminata inscriptio inventa, tantum posse mittere ad quamque inscriptionem semel singulare operatione.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: Transaction creation failed!</source>
        <translation>Error: Creare transactionem abortum est!</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected. This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: transactio reiecta est.  Hoc fiat si alii nummorum in tuo cassidili iam soluti sunt, ut si usus es exemplar de wallet.dat et nummi soluti sunt in exemplari sed non hic notati ut soluti.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+14"/>
        <source>Form</source>
        <translation>Schema</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>A&amp;mount:</source>
        <translation>&amp;Quantitas:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Pay &amp;To:</source>
        <translation>Pensa &amp;Ad:</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>The address to send the payment to (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Inscriptio cui mittere pensitationem (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+60"/>
        <location filename="../sendcoinsentry.cpp" line="+26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Insero titulum huic inscriptioni ut eam in tuum librum inscriptionum addas.</translation>
    </message>
    <message>
        <location line="-78"/>
        <source>&amp;Label:</source>
        <translation>&amp;Titulus:</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Choose address from address book</source>
        <translation>Selige inscriptionem ex libro inscriptionum</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>Conglutina inscriptionem ex latibulo</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Remove this recipient</source>
        <translation>Remove hunc accipientem</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+1"/>
        <source>Enter a FuelCoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Insero inscriptionem FuelCoin (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signationes - Signa / Verifica nuntium</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signa Nuntium</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Potes nuntios signare inscriptionibus tuis ut demonstres te eas possidere.  Cautus es non amibiguum signare, quia impetus phiscatorum conentur te fallere ut signes identitatem tuam ad eos.  Solas signa sententias cuncte descriptas quibus convenis.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Inscriptio qua signare nuntium (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+213"/>
        <source>Choose an address from the address book</source>
        <translation>Selige inscriptionem ex librum inscriptionum</translation>
    </message>
    <message>
        <location line="-203"/>
        <location line="+213"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="-203"/>
        <source>Paste address from clipboard</source>
        <translation>Glutina inscriptionem ex latibulo</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>Insere hic nuntium quod vis signare</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Signature</source>
        <translation>Signatio</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copia signationem in latibulum systematis</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Sign the message to prove you own this FuelCoin address</source>
        <translation>Signa nuntium ut demonstres hanc inscriptionem FuelCoin a te possessa esse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation>Signa &amp;Nuntium</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all sign message fields</source>
        <translation>Reconstitue omnes campos signandi nuntii</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+146"/>
        <source>Clear &amp;All</source>
        <translation>Vacuefac &amp;Omnia</translation>
    </message>
    <message>
        <location line="-87"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica Nuntium</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Insere inscriptionem signantem, nuntium (cura ut copias intermissiones linearum, spatia, tabs, et cetera exacte) et signationem infra ut nuntium verifices.  Cautus esto ne magis legas in signationem quam in nuntio signato ipso est, ut vites falli ab impetu homo-in-medio.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>The address the message was signed with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Inscriptio qua nuntius signatus est (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Verify the message to ensure it was signed with the specified FuelCoin address</source>
        <translation>Verifica nuntium ut cures signatum esse cum specifica inscriptione FuelCoin</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Verify &amp;Message</source>
        <translation>Verifica &amp;Nuntium</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Reset all verify message fields</source>
        <translation>Reconstitue omnes campos verificandi nuntii</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+27"/>
        <location line="+3"/>
        <source>Enter a FuelCoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Insere inscriptionem FuelCoin (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Clicca &quot;Signa Nuntium&quot; ut signatio generetur</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter FuelCoin signature</source>
        <translation>Insere signationem FuelCoin</translation>
    </message>
    <message>
        <location line="+82"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>Inscriptio inserta non valida est.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>Sodes inscriptionem proba et rursus conare.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>Inserta inscriptio clavem non refert.</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>Cassidilis reserare cancellatum est.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>Clavis privata absens est pro inserta inscriptione.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>Nuntium signare abortum est.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>Nuntius signatus.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>Signatio decodificari non potuit.</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>Sodes signationem proba et rursus conare.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>Signatio non convenit digesto nuntii</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>Nuntium verificare abortum est.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>Nuntius verificatus.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../splashscreen.cpp" line="+22"/>
        <source>The FuelCoin developers</source>
        <translation>FuelCoin curatores</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+20"/>
        <source>Open until %1</source>
        <translation>Apertum donec %1</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>%1/offline</source>
        <translation>%1/non conecto</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1/unconfirmed</source>
        <translation>%1/non confirmata</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 confirmations</source>
        <translation>%1 confirmationes</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <location line="+7"/>
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, disseminatum per %n nodo</numerusform><numerusform>, disseminata per %n nodis</numerusform></translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Date</source>
        <translation>Dies</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Source</source>
        <translation>Fons</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Generated</source>
        <translation>Generatum</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+17"/>
        <source>From</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+22"/>
        <location line="+58"/>
        <source>To</source>
        <translation>Ad</translation>
    </message>
    <message>
        <location line="-77"/>
        <location line="+2"/>
        <source>own address</source>
        <translation>inscriptio propria</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>label</source>
        <translation>titulus</translation>
    </message>
    <message>
        <location line="+37"/>
        <location line="+12"/>
        <location line="+45"/>
        <location line="+17"/>
        <location line="+30"/>
        <source>Credit</source>
        <translation>Creditum</translation>
    </message>
    <message numerus="yes">
        <location line="-102"/>
        <source>matures in %n more block(s)</source>
        <translation><numerusform>maturum erit in %n plure frusto</numerusform><numerusform>maturum erit in %n pluribus frustis</numerusform></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>not accepted</source>
        <translation>non acceptum</translation>
    </message>
    <message>
        <location line="+44"/>
        <location line="+8"/>
        <location line="+15"/>
        <location line="+30"/>
        <source>Debit</source>
        <translation>Debitum</translation>
    </message>
    <message>
        <location line="-39"/>
        <source>Transaction fee</source>
        <translation>Transactionis merces</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Net amount</source>
        <translation>Cuncta quantitas</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Message</source>
        <translation>Nuntius</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Comment</source>
        <translation>Annotatio</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transaction ID</source>
        <translation>ID transactionis</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated coins must mature 120 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Nummis generatis necesse est maturitas 120 frustorum antequam illi transmitti possunt.  Cum hoc frustum generavisti, disseminatum est ad rete ut addatur ad catenam frustorum.  Si aboritur inire catenam, status eius mutabit in &quot;non acceptum&quot; et non transmittabile erit.  Hoc interdum accidat si alter nodus frustum generat paucis secundis ante vel post tuum.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Debug information</source>
        <translation>Informatio de debug</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Transaction</source>
        <translation>Transactio</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Inputs</source>
        <translation>Lectenda</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>Quantitas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>verum</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>falsum</translation>
    </message>
    <message>
        <location line="-209"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, nondum prospere disseminatum est</translation>
    </message>
    <message numerus="yes">
        <location line="-35"/>
        <source>Open for %n more block(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform>Aperi pro %n pluribus frustis</numerusform></translation>
    </message>
    <message>
        <location line="+70"/>
        <source>unknown</source>
        <translation>ignotum</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+14"/>
        <source>Transaction details</source>
        <translation>Particularia transactionis</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Haec tabula monstrat descriptionem verbosam transactionis</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+225"/>
        <source>Date</source>
        <translation>Dies</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>Typus</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Inscriptio</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Quantitas</translation>
    </message>
    <message numerus="yes">
        <location line="+57"/>
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Aperi pro %n plure frusto</numerusform><numerusform>Aperi pro %n pluribus frustis</numerusform></translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open until %1</source>
        <translation>Apertum donec %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Non conectum (%1 confirmationes)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Non confirmatum (%1 de %2 confirmationibus)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmatum (%1 confirmationes)</translation>
    </message>
    <message numerus="yes">
        <location line="+8"/>
        <source>Mined balance will be available when it matures in %n more block(s)</source>
        <translation><numerusform>Fossum pendendum utibile erit quando id maturum est post %n plus frustum</numerusform><numerusform>Fossum pendendum utibile erit quando id maturum est post %n pluria frusta</numerusform></translation>
    </message>
    <message>
        <location line="+5"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Hoc frustum non acceptum est ab ulla alia nodis et probabiliter non acceptum erit!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated but not accepted</source>
        <translation>Generatum sed non acceptum</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>Received with</source>
        <translation>Acceptum cum</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>Acceptum ab</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>Missum ad</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>Pensitatio ad te ipsum</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mined</source>
        <translation>Fossa</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status transactionis.  Supervola cum mure ut monstretur numerus confirmationum.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Dies et tempus quando transactio accepta est.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>Typus transactionis.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Destination address of transaction.</source>
        <translation>Inscriptio destinationis transactionis.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Quantitas remota ex pendendo aut addita ei.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+52"/>
        <location line="+16"/>
        <source>All</source>
        <translation>Omne</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>Hodie</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>Hac hebdomade</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>Hoc mense</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>Postremo mense</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>Hoc anno</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>Intervallum...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>Acceptum cum</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>Missum ad</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>Ad te ipsum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mined</source>
        <translation>Fossa</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>Alia</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Enter address or label to search</source>
        <translation>Insere inscriptionem vel titulum ut quaeras</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Min amount</source>
        <translation>Quantitas minima</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>Copia inscriptionem</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Copia titulum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Copia quantitatem</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy transaction ID</source>
        <translation>Copia transactionis ID</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>Muta titulum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>Monstra particularia transactionis</translation>
    </message>
    <message>
        <location line="+139"/>
        <source>Export Transaction Data</source>
        <translation>Exporta Data Transactionum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma Separata Plica (*.csv)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Confirmed</source>
        <translation>Confirmatum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Dies</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>Typus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>Titulus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>Inscriptio</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Amount</source>
        <translation>Quantitas</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error exporting</source>
        <translation>Error exportandi</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Non potuisse scribere ad plicam %1.</translation>
    </message>
    <message>
        <location line="+100"/>
        <source>Range:</source>
        <translation>Intervallum:</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>ad</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+193"/>
        <source>Send Coins</source>
        <translation>Mitte Nummos</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <location filename="../walletview.cpp" line="+42"/>
        <source>&amp;Export</source>
        <translation>&amp;Exporta</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporta data in hac tabella in plicam</translation>
    </message>
    <message>
        <location line="+193"/>
        <source>Backup Wallet</source>
        <translation>Conserva cassidile</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Data cassidilis (*.dat)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Backup Failed</source>
        <translation>Conservare abortum est.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>Error erat conante salvare data cassidilis ad novum locum.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Backup Successful</source>
        <translation>Successum in conservando</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The wallet data was successfully saved to the new location.</source>
        <translation>Successum in salvando data cassidilis in novum locum.</translation>
    </message>
</context>
<context>
    <name>FuelCoin-core</name>
    <message>
        <location filename="../FuelCoinstrings.cpp" line="+94"/>
        <source>FuelCoin version</source>
        <translation>Versio de FuelCoin</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>Usage:</source>
        <translation>Usus:</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Send command to -server or FuelCoind</source>
        <translation>Mitte mandatum ad -server vel FuelCoind</translation>
    </message>
    <message>
        <location line="-23"/>
        <source>List commands</source>
        <translation>Enumera mandata</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Get help for a command</source>
        <translation>Accipe auxilium pro mandato</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Options:</source>
        <translation>Optiones:</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Specify configuration file (default: FuelCoin.conf)</source>
        <translation>Specifica configurationis plicam (praedefinitum: FuelCoin.conf)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Specify pid file (default: FuelCoind.pid)</source>
        <translation>Specifica pid plicam (praedefinitum: FuelCoin.pid)</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Specify data directory</source>
        <translation>Specifica indicem datorum</translation>
    </message>
    <message>
        <location line="-9"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Constitue magnitudinem databasis cache in megabytes (praedefinitum: 25)</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>Listen for connections on &lt;port&gt; (default: 9111 or testnet: 19111)</source>
        <translation>Ausculta pro conexionibus in &lt;porta&gt; (praedefinitum: 9111 vel testnet: 19111)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Manutene non plures quam &lt;n&gt; conexiones ad paria (praedefinitum: 125)</translation>
    </message>
    <message>
        <location line="-48"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Conecta ad nodum acceptare inscriptiones parium, et disconecte</translation>
    </message>
    <message>
        <location line="+82"/>
        <source>Specify your own public address</source>
        <translation>Specifica tuam propriam publicam inscriptionem</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Limen pro disconectendo paria improba (praedefinitum: 100)</translation>
    </message>
    <message>
        <location line="-134"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Numerum secundorum prohibere ne paria improba reconectant (praedefinitum: 86400)</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Error erat dum initians portam RPC %u pro auscultando in IPv4: %s</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 9222 or testnet: 19222)</source>
        <translation>Ausculta pro conexionibus JSON-RPC in &lt;porta&gt; (praedefinitum: 9222 vel testnet: 19222)</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accipe terminalis et JSON-RPC mandata.</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Operare infere sicut daemon et mandata accipe</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>Use the test network</source>
        <translation>Utere rete experimentale</translation>
    </message>
    <message>
        <location line="-112"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Accipe conexiones externas (praedefinitum: 1 nisi -proxy neque -connect)</translation>
    </message>
    <message>
        <location line="-80"/>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=FuelCoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;FuelCoin Alert&quot; admin@foo.com
</source>
        <translation>%s, necesse est te rpcpassword constituere in plica configurationis:
%s
Hortatur te hanc fortuitam tesseram uti:
rpcuser=FuelCoinrpc
rpcpassword=%s
(non est necesse te hanc tesseram meminisse)
Nomen usoris et tessera eadem esse NON POSSUNT.
Si plica non existit, eam crea cum permissionibus ut eius dominus tantum sinitur id legere.
Quoque hortatur alertnotify constituere ut tu notificetur de problematibus;
exempli gratia: alertnotify=echo %%s | mail -s &quot;FuelCoin Notificatio&quot; admin@foo.com
</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>Error erat dum initians portam RPC %u pro auscultando in IPv6, labens retrorsum ad IPv4: %s</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Conglutina ad inscriptionem datam et semper in eam ausculta.  Utere [moderatrum]:porta notationem pro IPv6</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot obtain a lock on data directory %s. FuelCoin is probably already running.</source>
        <translation>Non posse serare datorum indicem %s.  FuelCoin probabiliter iam operatur.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: Transactio eiecta est! Hoc possit accidere si alii nummorum in cassidili tuo iam soluti sint, ut si usus es exemplar de wallet.dat et nummi soluti sunt in exemplari sed non hic notati ut soluti.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Error: Huic transactioni necesse est merces saltem %s propter eius magnitudinem, complexitatem, vel usum recentum acceptorum nummorum!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Execute command when a relevant alert is received (%s in cmd is replaced by message)</source>
        <translation>Facere mandatum quotiescumque notificatio affinis accipitur (%s in mandato mutatur in nuntium) </translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Facere mandatum quotiescumque cassidilis transactio mutet (%s in mandato sbstituitur ab TxID)</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</source>
        <translation>Constitue magnitudinem maximam transactionum magnae-prioritatis/parvae-mercedis in octetis/bytes (praedefinitum: 27000)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Hoc est prae-dimittum experimentala aedes - utere eo periculo tuo proprio - nolite utere fodendo vel applicationibus mercatoriis</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Monitio: -paytxfee constitutum valde magnum!  Hoc est merces transactionis solves si mittis transactionem.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Displayed transactions may not be correct! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Monitio: Monstratae transactiones fortasse non recta sint! Forte oportet tibi progredere, an aliis nodis progredere.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong FuelCoin will not work properly.</source>
        <translation>Monitio: Sodes cura ut dies tempusque computatri tui recti sunt!  Si horologium tuum pravum est, FuelCoin non proprie fungetur.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Monitio: error legendo wallet.dat!  Omnes claves recte lectae, sed data transactionum vel libri inscriptionum fortasse desint vel prava sint.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Monitio: wallet.data corrupta, data salvata!  Originalis wallet.dat salvata ut wallet.{timestamp}.bak in %s; si pendendum tuum vel transactiones pravae sunt, oportet ab conservato restituere.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Conare recipere claves privatas de corrupto wallet.dat</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Block creation options:</source>
        <translation>Optiones creandi frustorum:</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Connect only to the specified node(s)</source>
        <translation>Conecte sole ad nodos specificatos (vel nodum specificatum)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Corrupted block database detected</source>
        <translation>Corruptum databasum frustorum invenitur</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Discooperi propriam inscriptionem IP (praedefinitum: 1 quando auscultans et nullum -externalip)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Visne reficere databasum frustorum iam?</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error initializing block database</source>
        <translation>Error initiando databasem frustorum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Error initiando systematem databasi cassidilis %s!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading block database</source>
        <translation>Error legendo frustorum databasem</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error opening block database</source>
        <translation>Error aperiendo databasum frustorum</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error: Disk space is low!</source>
        <translation>Error: Inopia spatii disci!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Error: Cassidile seratum, non posse transactionem creare!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: system error: </source>
        <translation>Error: systematis error:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Non potuisse auscultare in ulla porta.  Utere -listen=0 si hoc vis.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block info</source>
        <translation>Non potuisse informationem frusti legere </translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to read block</source>
        <translation>Non potuisse frustum legere</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to sync block index</source>
        <translation>Synchronizare indicem frustorum abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block index</source>
        <translation>Scribere indicem frustorum abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block info</source>
        <translation>Scribere informationem abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write block</source>
        <translation>Scribere frustum abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write file info</source>
        <translation>Scribere informationem plicae abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write to coin database</source>
        <translation>Scribere databasem nummorum abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write transaction index</source>
        <translation>Scribere indicem transactionum abortum est</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Failed to write undo data</source>
        <translation>Scribere data pro cancellando mutationes abortum est</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>Inveni paria utendo DNS quaerendo (praedefinitum: 1 nisi -connect)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Generate coins (default: 0)</source>
        <translation>Genera nummos (praedefinitum: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>Quot frusta proba ad initium (praedefinitum: 288, 0 = omnia)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-4, default: 3)</source>
        <translation>Quam perfecta frustorum verificatio est (0-4, praedefinitum: 3)</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Not enough file descriptors available.</source>
        <translation>Inopia descriptorum plicarum.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Restituere indicem catenae frustorum ex activis plicis blk000??.dat</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>Constitue numerum filorum ad tractandum RPC postulationes (praedefinitum: 4)</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Verifying blocks...</source>
        <translation>Verificante frusta...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Verifying wallet...</source>
        <translation>Verificante cassidilem...</translation>
    </message>
    <message>
        <location line="-69"/>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Importat frusta ab externa plica blk000??.dat</translation>
    </message>
    <message>
        <location line="-76"/>
        <source>Set the number of script verification threads (up to 16, 0 = auto, &lt;0 = leave that many cores free, default: 0)</source>
        <translation>Constitue numerum filorum verificationis scriptorum (Maximum 16, 0 = auto, &lt;0 = tot corda libera erunt, praedefinitum: 0)</translation>
    </message>
    <message>
        <location line="+77"/>
        <source>Information</source>
        <translation>Informatio</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Invalid -tor address: &apos;%s&apos;</source>
        <translation>Inscriptio -tor non valida: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Quantitas non valida pro -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Quantitas non valida pro -mintxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>Manutene completam indicem transactionum (praedefinitum: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maxima magnitudo memoriae pro datis accipendis singulis conexionibus, &lt;n&gt;*1000 octetis/bytes (praedefinitum: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maxima magnitudo memoriae pro datis mittendis singulis conexionibus, &lt;n&gt;*1000 octetis/bytes (praedefinitum: 1000)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>Tantum accipe catenam frustorum convenientem internis lapidibus (praedefinitum: 1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Tantum conecte ad nodos in rete &lt;net&gt; (IPv4, IPv6 aut Tor)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Output extra debugging information. Implies all other -debug* options</source>
        <translation>Exscribe additiciam informationem pro debug.  Implicat omnes alias optiones -debug*</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Output extra network debugging information</source>
        <translation>Exscribe additiciam informationem pro retis debug.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Antepone pittacium temporis ante exscriptum de debug </translation>
    </message>
    <message>
        <location line="+5"/>
        <source>SSL options: (see the FuelCoin Wiki for SSL setup instructions)</source>
        <translation>Optiones SSL: (vide vici de FuelCoin pro instructionibus SSL configurationis)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Select the version of socks proxy to use (4-5, default: 5)</source>
        <translation>Selige versionem socks vicarii utendam (4-5, praedefinitum: 5)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Mitte informationem vestigii/debug ad terminale potius quam plicam debug.log</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Mitte informationem vestigii/debug ad debugger</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Set maximum block size in bytes (default: 250000)</source>
        <translation>Constitue maximam magnitudinem frusti in octetis/bytes (praedefinitum: 250000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Constitue minimam magnitudinem frusti in octetis/bytes (praedefinitum: 0)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Diminue plicam debug.log ad initium clientis (praedefinitum: 1 nisi -debug)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Signing transaction failed</source>
        <translation>Signandum transactionis abortum est</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Specifica tempumfati conexionis in millisecundis (praedefinitum: 5000)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>System error: </source>
        <translation>Systematis error:</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Transaction amount too small</source>
        <translation>Magnitudo transactionis nimis parva</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction amounts must be positive</source>
        <translation>Necesse est magnitudines transactionum positivas esse.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Transaction too large</source>
        <translation>Transactio nimis magna</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Utere UPnP designare portam auscultandi (praedefinitum: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Utere UPnP designare portam auscultandi (praedefinitum: 1 quando auscultans)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use proxy to reach tor hidden services (default: same as -proxy)</source>
        <translation>Utere vicarium ut extendas ad tor servitia occulta (praedefinitum: idem ut -proxy)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Nomen utentis pro conexionibus JSON-RPC</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Warning</source>
        <translation>Monitio</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Monitio: Haec versio obsoleta est, progressio postulata!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>You need to rebuild the databases using -reindex to change -txindex</source>
        <translation>Oportet recreare databases utendo -reindex ut mutes -txindex</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat corrupta, salvare abortum est</translation>
    </message>
    <message>
        <location line="-50"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Tessera pro conexionibus JSON-RPC</translation>
    </message>
    <message>
        <location line="-67"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Permitte conexionibus JSON-RPC ex inscriptione specificata</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Mitte mandata nodo operanti in &lt;ip&gt; (praedefinitum: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-120"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Pelle mandatum quando optissimum frustum mutat (%s in mandato substituitur ab hash frusti)</translation>
    </message>
    <message>
        <location line="+147"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Progredere cassidile ad formam recentissimam</translation>
    </message>
    <message>
        <location line="-21"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Constitue magnitudinem stagni clavium ad &lt;n&gt; (praedefinitum: 100)</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Iterum perlege catenam frustorum propter absentes cassidilis transactiones</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Utere OpenSSL (https) pro conexionibus JSON-RPC</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Plica certificationis daemonis moderantis (praedefinitum: server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Clavis privata daemonis moderans (praedefinitum: server.pem)</translation>
    </message>
    <message>
        <location line="-151"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Acceptabiles cifrae (praedefinitum: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location line="+165"/>
        <source>This help message</source>
        <translation>Hic nuntius auxilii</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Non posse conglutinare ad %s in hoc computatro (conglutinare redidit errorem %d, %s)</translation>
    </message>
    <message>
        <location line="-91"/>
        <source>Connect through socks proxy</source>
        <translation>Conecte per socks vicarium</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permitte quaerenda DNS pro -addnode, -seednode, et -connect</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Loading addresses...</source>
        <translation>Legens inscriptiones...</translation>
    </message>
    <message>
        <location line="-35"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Error legendi wallet.dat: Cassidile corruptum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading wallet.dat: Wallet requires newer version of FuelCoin</source>
        <translation>Error legendi wallet.dat: Cassidili necesse est recentior versio FuelCoin</translation>
    </message>
    <message>
        <location line="+93"/>
        <source>Wallet needed to be rewritten: restart FuelCoin to complete</source>
        <translation>Cassidili necesse erat rescribi: Repelle FuelCoin ut compleas</translation>
    </message>
    <message>
        <location line="-95"/>
        <source>Error loading wallet.dat</source>
        <translation>Error legendi wallet.dat</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Inscriptio -proxy non valida: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Ignotum rete specificatum in -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Ignota -socks vicarii versio postulata: %i</translation>
    </message>
    <message>
        <location line="-96"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Non posse resolvere -bind inscriptonem: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Non posse resolvere -externalip inscriptionem: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Quantitas non valida pro -paytxfee=&lt;quantitas&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Invalid amount</source>
        <translation>Quantitas non valida</translation>
    </message>
    <message>
        <location line="-6"/>
        <source>Insufficient funds</source>
        <translation>Inopia nummorum</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Loading block index...</source>
        <translation>Legens indicem frustorum...</translation>
    </message>
    <message>
        <location line="-57"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Adice nodum cui conectere et conare sustinere conexionem apertam</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Unable to bind to %s on this computer. FuelCoin is probably already running.</source>
        <translation>Non posse conglutinare ad %s in hoc cumputatro.  FuelCoin probabiliter iam operatur.</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>Merces per KB addere ad transactiones tu mittas</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Loading wallet...</source>
        <translation>Legens cassidile...</translation>
    </message>
    <message>
        <location line="-52"/>
        <source>Cannot downgrade wallet</source>
        <translation>Non posse cassidile regredi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>Non posse scribere praedefinitam inscriptionem</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Rescanning...</source>
        <translation>Iterum perlegens...</translation>
    </message>
    <message>
        <location line="-57"/>
        <source>Done loading</source>
        <translation>Completo lengendi</translation>
    </message>
    <message>
        <location line="+82"/>
        <source>To use the %s option</source>
        <translation>Ut utaris optione %s</translation>
    </message>
    <message>
        <location line="-74"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location line="-31"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Necesse est te rpcpassword=&lt;tesseram&gt; constituere in plica configurationum:
%s
Si plica non existat, crea eam cum permissionibus ut solus eius dominus eam legere sinatur.</translation>
    </message>
</context>
</TS>